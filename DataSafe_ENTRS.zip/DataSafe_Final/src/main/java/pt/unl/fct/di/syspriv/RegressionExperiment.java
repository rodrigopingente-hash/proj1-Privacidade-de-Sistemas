package pt.unl.fct.di.syspriv;

import pt.unl.fct.di.syspriv.entities.AnonymousHealthData;
import pt.unl.fct.di.syspriv.kanonymity.KAnonymityTool;
import pt.unl.fct.di.syspriv.util.ConfigLoader;
import pt.unl.fct.di.syspriv.util.LinearRegression;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Experiencia ilustrativa com seis observacoes ficticias.
 * As metricas sao avaliadas sobre dados originais e NAO sao privadas.
 */
public class RegressionExperiment {
    private static final int YEAR = 2026;
    private static final double MAX_AGE = 120.0;
    private static final double MAX_GLUCOSE = 600.0;
    private static final SecureRandom RANDOM = new SecureRandom();

    public static void main(String[] args) {
        System.out.println("=== EXPERIENCIA DE REGRESSAO LINEAR ===");

        List<AnonymousHealthData> records = createRecords();
        double[] originalAges = ages(records);
        double[] originalGlucose = glucose(records);
        LinearRegression regression = new LinearRegression();

        System.out.println("\n--- CASO 1: Dados originais ---");
        LinearRegression.RegressionResult original = regression.run(originalAges, originalGlucose);
        printResult("Original", original, originalAges, originalGlucose);

        KAnonymityTool<AnonymousHealthData> tool = new KAnonymityTool<>(3, 0.2f);

        System.out.println("\n--- CASO 2: K-Anonymity (k=3) ---");
        try {
            List<AnonymousHealthData> anonymized = tool.runMondrain(records);
            printGeneralization("MONDRIAN", anonymized);
            runGeneralizedRegression("K-Anonymity", anonymized, regression,
                    originalAges, originalGlucose);
        } catch (Exception e) {
            System.out.println("Erro no Caso 2: " + e.getMessage());
        }

        System.out.println("\n--- CASO 3: K-Anonymity + T-Closeness (k=3, t=0.2) ---");
        try {
            List<AnonymousHealthData> anonymized = tool.runTCloseMondrain(records);
            printGeneralization("T-CLOSENESS", anonymized);
            runGeneralizedRegression("T-Closeness", anonymized, regression,
                    originalAges, originalGlucose);
        } catch (Exception e) {
            System.out.println("Erro no Caso 3: " + e.getMessage());
        }

        System.out.println("\n--- CASO 4: Differential Privacy (regressao) ---");
        double epsilon = ConfigLoader.getDoubleProperty("dp.epsilon", 5.0);
        if (!Double.isFinite(epsilon) || epsilon <= 0.0) {
            throw new IllegalArgumentException("dp.epsilon deve ser positivo e finito");
        }
        System.out.println("Epsilon configurado: " + epsilon);
        System.out.println("Orcamento dividido entre 5 estatisticas agregadas.");

        RegressionCoefficients dp = privateRegression(originalAges, originalGlucose, epsilon);
        if (dp == null) {
            System.out.println("Regressao DP numericamente indefinida nesta execucao.");
        } else {
            printCoefficients("Differential Privacy", dp.slope, dp.intercept,
                    originalAges, originalGlucose);
        }
        System.out.println("\nNOTA: R2/MSE sao calculados sobre dados originais apenas para avaliacao experimental.");
        System.out.println("Nao devem ser publicados como metricas diferencialmente privadas.");
        System.out.println("=== FIM DA EXPERIENCIA ===");
    }

    private static List<AnonymousHealthData> createRecords() {
        List<AnonymousHealthData> records = new ArrayList<>();
        Date date = new Date();
        records.add(new AnonymousHealthData(1L, 1994, 2725, 90, date));
        records.add(new AnonymousHealthData(2L, 1984, 2725, 110, date));
        records.add(new AnonymousHealthData(3L, 1974, 2726, 130, date));
        records.add(new AnonymousHealthData(4L, 1964, 2726, 155, date));
        records.add(new AnonymousHealthData(5L, 1954, 2727, 180, date));
        records.add(new AnonymousHealthData(6L, 1990, 2728, 95, date));
        return records;
    }

    private static double[] ages(List<AnonymousHealthData> records) {
        double[] values = new double[records.size()];
        for (int i = 0; i < values.length; i++) {
            values[i] = YEAR - records.get(i).getPatientBirthYear();
        }
        return values;
    }

    private static double[] generalizedAges(List<AnonymousHealthData> records) {
        double[] values = new double[records.size()];
        for (int i = 0; i < values.length; i++) {
            values[i] = YEAR - generalizedBirthYear(records.get(i));
        }
        return values;
    }

    private static double generalizedBirthYear(AnonymousHealthData record) {
        Object value = record.getQuasiIdentifiers().get("birthYear");
        if (value == null) {
            throw new IllegalArgumentException("Ano de nascimento em falta");
        }
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }
        String interval = value.toString().trim();
        String[] parts = interval.split("\\s*-\\s*");
        if (parts.length == 2) {
            double min = Double.parseDouble(parts[0]);
            double max = Double.parseDouble(parts[1]);
            if (min > max) {
                throw new IllegalArgumentException("Intervalo de nascimento invalido: " + interval);
            }
            return (min + max) / 2.0;
        }
        return Double.parseDouble(interval);
    }

    private static double[] glucose(List<AnonymousHealthData> records) {
        double[] values = new double[records.size()];
        for (int i = 0; i < values.length; i++) {
            values[i] = records.get(i).getGlucose();
        }
        return values;
    }

    private static void printGeneralization(String label, List<AnonymousHealthData> records) {
        System.out.println("\n=== VALORES APOS " + label + " ===");
        for (AnonymousHealthData record : records) {
            System.out.println("ID: " + record.getId()
                    + " | Ano original: " + record.getPatientBirthYear()
                    + " | Ano generalizado: " + record.getQuasiIdentifiers().get("birthYear")
                    + " | Glicose: " + record.getGlucose());
        }
    }

    private static void runGeneralizedRegression(String name,
                                                 List<AnonymousHealthData> anonymized, LinearRegression regression,
                                                 double[] originalAges, double[] originalGlucose) {
        double[] x = generalizedAges(anonymized);
        double[] y = glucose(anonymized);
        if (x.length < 2 || x.length != y.length) {
            System.out.println(name + ": observacoes insuficientes para regressao.");
            return;
        }
        double min = x[0], max = x[0];
        for (double age : x) {
            min = Math.min(min, age);
            max = Math.max(max, age);
        }
        if (Math.abs(max - min) < 1e-9) {
            System.out.println(name + ": regressao nao estimavel: todas as idades generalizadas sao iguais ("
                    + min + "). R2/MSE da regressao: N/A.");
            return;
        }
        LinearRegression.RegressionResult result = regression.run(x, y);
        printResult(name, result, originalAges, originalGlucose);
    }

    private static void printResult(String name, LinearRegression.RegressionResult r,
                                    double[] originalAges, double[] originalGlucose) {
        printCoefficients(name, r.getSlope(), r.getIntercept(), originalAges, originalGlucose);
        System.out.println("R2 no conjunto de treino: " + r.getRSquare());
        System.out.println("MSE no conjunto de treino: " + r.getMeanSquareError());
    }

    private static void printCoefficients(String name, double slope, double intercept,
                                          double[] ages, double[] glucose) {
        System.out.printf("%s | slope=%.6f | intercept=%.6f%n", name, slope, intercept);
        double mean = 0;
        for (double value : glucose) mean += value;
        mean /= glucose.length;
        double sse = 0, sst = 0;
        for (int i = 0; i < ages.length; i++) {
            double error = glucose[i] - (intercept + slope * ages[i]);
            sse += error * error;
            double deviation = glucose[i] - mean;
            sst += deviation * deviation;
        }
        System.out.printf("R2 (avaliacao nao privada)=%.6f | MSE (avaliacao nao privada)=%.6f%n",
                sst > 0 ? 1 - sse / sst : Double.NaN, sse / ages.length);
    }

    /**
     * Laplace sobre cinco somas: n, sum(x), sum(y), sum(x*x), sum(x*y).
     * Pressupoe no maximo uma observacao por pessoa e adjacencia add/remove.
     * Limites: idade [0,120], glicose [0,600].
     */
    private static RegressionCoefficients privateRegression(double[] ages, double[] glucose,
                                                            double epsilon) {
        if (ages.length != glucose.length || ages.length < 2) {
            throw new IllegalArgumentException("Dados insuficientes ou incompativeis");
        }
        double n = 0, sx = 0, sy = 0, sxx = 0, sxy = 0;
        for (int i = 0; i < ages.length; i++) {
            double x = Math.max(0, Math.min(MAX_AGE, ages[i]));
            double y = Math.max(0, Math.min(MAX_GLUCOSE, glucose[i]));
            n++;
            sx += x;
            sy += y;
            sxx += x * x;
            sxy += x * y;
        }
        double share = epsilon / 5.0;
        double noisyN = n + laplace(1.0 / share);
        double noisySx = sx + laplace(MAX_AGE / share);
        double noisySy = sy + laplace(MAX_GLUCOSE / share);
        double noisySxx = sxx + laplace(MAX_AGE * MAX_AGE / share);
        double noisySxy = sxy + laplace(MAX_AGE * MAX_GLUCOSE / share);

        if (noisyN <= 0) return null;
        double denominator = noisyN * noisySxx - noisySx * noisySx;
        if (Math.abs(denominator) < 1e-9) return null;
        double slope = (noisyN * noisySxy - noisySx * noisySy) / denominator;
        double intercept = (noisySy - slope * noisySx) / noisyN;
        if (!Double.isFinite(slope) || !Double.isFinite(intercept)) return null;
        return new RegressionCoefficients(slope, intercept);
    }

    private static double laplace(double scale) {
        double u = RANDOM.nextDouble() - 0.5;
        return -scale * Math.signum(u) * Math.log1p(-2.0 * Math.abs(u));
    }

    private static class RegressionCoefficients {
        final double slope;
        final double intercept;

        RegressionCoefficients(double slope, double intercept) {
            this.slope = slope;
            this.intercept = intercept;
        }
    }
}
